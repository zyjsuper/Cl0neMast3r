# Changelog
All changes to Cl0neMast3r will be documented in this file.

## [1.0] - 2018-03-08
### Added
- Cl0neMast3r is using API now to be faster.
- You can add a tool using URL.
- Search for tools with the tool name or username.
- Reinstall all your tools.
- Update all your tools.
- Update old tools only.
- Export your tools list to HTML page.
- Import your tools from HTML page.
- Import your installed tools.
